class Pessoa {
    constructor(nome, idade, dataNasc) {
        this._nome = nome;
        this._idade = idade;
        this._dataNasc = dataNasc;
    }
    get nome() {
        return this._nome;
    }
    set nome(adiNovoNome) {
        this._nome = adiNovoNome;
    }
    get idade() {
        return this._idade;
    }
    set idade(adiNovaIdade) {
        this._idade = adiNovaIdade;
    }
    get dataNasc() {
        return this._dataNasc;
    }
    set dataNasc(adiNovaDataNascimento) {
        this._dataNasc = adiNovaDataNascimento;
    }
}
