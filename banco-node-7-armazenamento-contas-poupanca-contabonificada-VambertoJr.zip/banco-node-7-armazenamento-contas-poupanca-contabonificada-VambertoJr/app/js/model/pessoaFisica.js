class PessoaFisica extends Pessoa {
    constructor(nome, idade, dataNasc, cpf) {
        super(nome, idade, dataNasc);
        this._cpf = cpf;
    }
    get cpf() {
        return this._cpf;
    }
}
