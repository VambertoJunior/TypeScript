let contaController = new ContaController();

contaController.listar();

const c1 = new Conta('1', 100);
const p1 = new Poupanca('2', 100);
const cb1 = new ContaBonificada('3', 0);

console.log('Conta: ' + c1.saldo);

p1.atualizarSaldoAniversario();
console.log('Poupanca: ' + p1.saldo);

cb1.creditar(100);
console.log('Conta Bonificada: ' + cb1.saldo);

const pes1 = new Pessoa("Vamberto", 22, new Date("15-02-1999"));
const pesFis = new PessoaFisica("Gustavo", 35, new Date("30-06-1989"), "543.764.391-30");
const pesJur = new PessoaJuridica("NET", 10, new Date("25-08-2013"),"334.554.836-58");

console.log(pes1.nome);
console.log(pesFis.nome);
console.log(pesJur.nome);
console.log(pesFis.cpf);
console.log(pesJur.cnpj);
