class Pessoa{
    private _nome: String;
    private _idade: number;
    private _dataNasc: Date;

    constructor(nome: String, idade: number, dataNasc: Date){
        this._nome = nome;
        this._idade = idade;
        this._dataNasc = dataNasc;
    }

    get nome(): String{
        return this._nome;
    }

    set nome(adiNovoNome: String){
        this._nome = adiNovoNome;
    }

    get idade(): number{
        return this._idade;
    }

    set idade(adiNovaIdade: number) {
        this._idade = adiNovaIdade;
    }

    get dataNasc(): Date {
        return this._dataNasc;
    }
    
    set dataNasc(adiNovaDataNascimento: Date) {
        this._dataNasc = adiNovaDataNascimento;
    }
}