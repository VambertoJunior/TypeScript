class PessoaFisica extends Pessoa{
    private _cpf: String;

    constructor(nome: String, idade: number, dataNasc: Date, cpf: String){
        super(nome +  " - Física", idade, dataNasc);
        this._cpf = cpf;
    }

    get cpf(): String{
        return this._cpf;
    }
}