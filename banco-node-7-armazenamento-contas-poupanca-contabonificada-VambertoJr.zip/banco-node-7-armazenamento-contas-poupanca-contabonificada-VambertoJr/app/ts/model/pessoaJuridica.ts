class PessoaJuridica extends Pessoa{
    private _cnpj: String;

    constructor(nome: String, idade: number, dataNasc: Date, cnpj: String){
        super(nome + "- Jurídica", idade, dataNasc);
        this._cnpj = cnpj;
    }

    get cnpj(): String{
        return this._cnpj;
    }
}